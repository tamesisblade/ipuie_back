<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Plantillas extends Model
{
    protected $table = 'plantillas';
    protected $primaryKey = 'id_plantilla';
}
