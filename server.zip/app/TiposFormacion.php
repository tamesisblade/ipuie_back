<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TiposFormacion extends Model
{
    protected $table = 'tipos_formacion';
    protected $primaryKey = 'id_tipo_formacion'
}
