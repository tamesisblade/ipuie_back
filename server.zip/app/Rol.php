<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rol extends Model
{
    protected $table = "sys_group_users";
	public $timestamps = true;
}
