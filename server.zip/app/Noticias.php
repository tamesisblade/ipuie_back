<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Noticias extends Model
{
    protected $table = 'not_noticias';
    protected $primaryKey = 'id_noticia';
}
