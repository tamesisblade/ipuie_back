<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nominativos extends Model
{
    protected $table = 'nominativos';
    protected $primaryKey = 'id_nominativo'
}
