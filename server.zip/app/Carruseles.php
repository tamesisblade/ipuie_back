<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carruseles extends Model
{
    protected $table = 'lay_carruseles';
    protected $primaryKey = 'id_carrusel';
}
