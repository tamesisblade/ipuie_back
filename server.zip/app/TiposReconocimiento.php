<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TiposReconocimiento extends Model
{
    protected $table = 'tipos_reconocimiento';
    protected $primaryKey = 'id_tipo_reconocimiento';
}
