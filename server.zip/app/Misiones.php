<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Misiones extends Model
{
    protected $table = 'misiones';
    protected $primaryKey = 'id_mision';
}
