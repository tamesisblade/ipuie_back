<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Eventos extends Model
{
    protected $table = 'agenda_usuario';
    protected $primaryKey = 'id';
}
