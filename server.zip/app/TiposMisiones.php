<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TiposMisiones extends Model
{
    protected $table = 'tipos_misiones';
    protected $primaryKey = 'id_tipo_mision';
}
