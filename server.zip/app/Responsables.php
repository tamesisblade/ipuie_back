<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Responsables extends Model
{
    protected $table = 'responsables';
    protected $primaryKey = 'id_responsable';
}
