<template>
	<div>
        <section class="jumbotron text-center">
            <div class="container">
                <h1 class="jumbotron-heading">Blog</h1>
            </div>
        </section>
    
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <posts></posts>
                </div>
            </div>
        </div>
    </div>
</template>

