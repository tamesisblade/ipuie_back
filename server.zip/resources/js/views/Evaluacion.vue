<template>
<v-app>
    <div>
        <h1>Evaluaciones</h1>
    </div>
</v-app>
</template>

<script>
import 'vuetify/dist/vuetify.min.css'
import Vue from 'vue'
import Vuetify from 'vuetify'
Vue.use(VueAlertify);
export default {

}
</script>
