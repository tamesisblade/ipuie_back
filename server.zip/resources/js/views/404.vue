<template>
	<div class="col-md-8">
		<h1 class="display-3">Error 404</h1>
		<p class="lead">.....</p>
	</div>
</template>