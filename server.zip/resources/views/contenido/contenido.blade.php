<!-- @extends('principal')
@section('contenido')
<template>
    <header-component></header-component>
</template>
<template v-if="menu==1">
    <usuario-component></usuario-component>
</template>
<template v-if="menu==2">
    <institucion-component></institucion-component>
</template>
<template v-if="menu==3">
    <vendedor-component></vendedor-component>
</template>
<template v-if="menu==4">
    <accesos-component></accesos-component>
</template>
<template v-if="menu==5">
    <libro-component></libro-component>
</template>
<template v-if="menu==6">
    <cuaderno-component></cuaderno-component>
</template>
<template v-if="menu==7">
    <planificacion-component></planificacion-component>
</template>
<template v-if="menu==8">
    <guia-component></guia-component>
</template>
<template v-if="menu==9">
    <material-component></material-component>
</template>
<template v-if="menu==10">
    <video-component></video-component>
</template>
<template v-if="menu==11">
    <audio-component></audio-component>
</template>
<template v-if="menu==12">
    <registarplanlector-component></registarplanlector-component>
</template>
<template v-if="menu==13">
    <registarlibro-component></registarlibro-component>
</template>
<template v-if="menu==14">
    <registarcuaderno-component></registarcuaderno-component>
</template>
<template v-if="menu==15">
    <registarguia-component></registarguia-component>
</template>
<template v-if="menu==16">
    <registarplanificacion-component></registarplanificacion-component>
</template>
<template v-if="menu==17">
    <registarmaterial-component></registarmaterial-component>
</template>
<template v-if="menu==18">
    <registarvideo-component></registarvideo-component>
</template>
<template v-if="menu==19">
    <registaraudio-component></registaraudio-component>
</template>
<template v-if="menu==20">
    <planlector-component></planlector-component>
</template>
<template v-if="menu==21">
    <registarasignatura-component></registarasignatura-component>
</template>
<template v-if="menu==22">
    <periodoescolar-component></periodoescolar-component>
</template>
<template v-if="menu==23">
    <papelera-component></papelera-component>
</template>
<template v-if="menu==24">
    <chat-component></chat-component>
</template>
<template v-if="menu==25">
    <classroom-component></classroom-component>
</template>
<template v-if="menu==26">
    <informacion-component></informacion-component>
</template>
<template v-if="menu==27">
    <contenido-component></contenido-component>
</template>
<template v-if="menu==28">
    <juegos-component></juegos-component>
</template>
@endsection -->